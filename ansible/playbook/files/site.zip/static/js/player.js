/* Hinterland Archive — live player (bilingual)
 *
 * Streams a public CC-licensed broadcast from SomaFM with fallback chain.
 * UI strings adapt to <html lang>.
 */

(function () {
  const playBtn  = document.getElementById('playBtn');
  if (!playBtn) return;
  const status   = document.getElementById('status');
  const bitrate  = document.getElementById('bitrate');
  const npTitle  = document.getElementById('np-title');
  const npMeta   = document.getElementById('np-meta');
  const volSlide = document.getElementById('vol');
  const wf       = document.getElementById('waveform');
  const lang     = document.documentElement.lang || 'ru';

  // Localised UI strings
  const strings = lang === 'ru' ? {
    play_aria: 'Включить прямой эфир',
    pause_aria: 'Поставить на паузу',
    loading_aria: 'Загрузка',
    buffering: 'Буферизация',
    streaming: 'Прямой эфир',
    paused: 'На паузе',
    reconnecting: 'Переподключение…',
    unreachable: 'Поток недоступен',
    all_offline: 'все источники недоступны',
    bitrate_streaming: '128 кбит/с · Opus'
  } : {
    play_aria: 'Play live stream',
    pause_aria: 'Pause live stream',
    loading_aria: 'Loading',
    buffering: 'Buffering',
    streaming: 'Streaming live',
    paused: 'Paused',
    reconnecting: 'Reconnecting…',
    unreachable: 'Stream unreachable',
    all_offline: 'all sources offline',
    bitrate_streaming: '128 kbps · Opus'
  };

  // Build the waveform bars once
  if (wf) {
    for (let i = 0; i < 96; i++) {
      const b = document.createElement('div');
      b.className = 'bar';
      b.style.height = (8 + Math.random() * 8) + 'px';
      wf.appendChild(b);
    }
  }

  // Stream sources, in order of preference
  const sources = [
    '/stream/main.opus',
    '/stream/main.mp3',
    'https://ice2.somafm.com/dronezone-128-mp3',
    'https://ice2.somafm.com/deepspaceone-128-mp3'
  ];

  let audio = null;
  let playing = false;
  let wfTimer = null;

  function animateWaveform(on) {
    if (!wf) return;
    if (on) {
      wf.classList.add('playing');
      wfTimer = setInterval(() => {
        Array.from(wf.children).forEach(b => {
          const h = 6 + Math.random() * 68;
          b.style.height = h + 'px';
        });
      }, 100);
    } else {
      wf.classList.remove('playing');
      clearInterval(wfTimer); wfTimer = null;
      Array.from(wf.children).forEach(b => {
        b.style.height = (8 + Math.random() * 8) + 'px';
      });
    }
  }

  function setIcon(state) {
    if (state === 'pause') {
      playBtn.innerHTML = '<svg viewBox="0 0 24 24"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>';
      playBtn.setAttribute('aria-label', strings.pause_aria);
    } else if (state === 'loading') {
      playBtn.innerHTML = '<svg viewBox="0 0 24 24" style="animation: spin 1s linear infinite;"><circle cx="12" cy="12" r="8" fill="none" stroke="currentColor" stroke-width="2" stroke-dasharray="20 30"/></svg>';
      playBtn.setAttribute('aria-label', strings.loading_aria);
    } else {
      playBtn.innerHTML = '<svg viewBox="0 0 24 24"><polygon points="6,4 20,12 6,20"/></svg>';
      playBtn.setAttribute('aria-label', strings.play_aria);
    }
  }

  // Inject keyframe for spinner
  const sty = document.createElement('style');
  sty.textContent = '@keyframes spin { to { transform: rotate(360deg); } }';
  document.head.appendChild(sty);

  function tryNextSource(idx) {
    if (idx >= sources.length) {
      status.textContent = strings.unreachable;
      bitrate.textContent = strings.all_offline;
      setIcon('play');
      return;
    }
    if (audio) { try { audio.pause(); } catch(e){} audio = null; }
    audio = new Audio();
    audio.crossOrigin = 'anonymous';
    audio.preload = 'none';
    audio.volume = (volSlide ? volSlide.value : 70) / 100;

    audio.addEventListener('loadstart', () => {
      status.textContent = strings.buffering;
      setIcon('loading');
    });
    audio.addEventListener('playing', () => {
      playing = true;
      status.textContent = strings.streaming;
      bitrate.textContent = strings.bitrate_streaming;
      setIcon('pause');
      animateWaveform(true);
    });
    audio.addEventListener('pause', () => {
      playing = false;
      status.textContent = strings.paused;
      setIcon('play');
      animateWaveform(false);
    });
    audio.addEventListener('error', () => {
      animateWaveform(false);
      tryNextSource(idx + 1);
    });
    audio.addEventListener('stalled', () => {
      status.textContent = strings.reconnecting;
    });

    audio.src = sources[idx];
    audio.play().catch(() => tryNextSource(idx + 1));
  }

  playBtn.addEventListener('click', () => {
    if (!audio || audio.paused) {
      tryNextSource(0);
    } else {
      audio.pause();
    }
  });

  if (volSlide) {
    volSlide.addEventListener('input', () => {
      if (audio) audio.volume = volSlide.value / 100;
    });
  }

  // Rotating "now playing" titles, localised
  const programsRu = [
    { title: 'Тихие часы: Онежское озеро',     meta: 'Записал В. Соколов · Карелия, РФ · 04:00 UTC, май 2025 · 4 часа' },
    { title: 'Длинное слушание: ледники',       meta: 'Непрерывные записи с Ватнайёкюдля и из Патагонии' },
    { title: 'Утренний хор, мульти-станция',    meta: 'Одновременный эфир · Водлозерский, Беловежская пуща, Килларни' },
    { title: 'Сезон свистунов',                 meta: 'VLF-записи с патагонской антенной сети · программа Д. Ортиса' },
    { title: 'Базарные плёнки',                 meta: 'Три центральноазиатских рынка · куратор А. Раззаков' },
    { title: 'Ледоход реки',                    meta: 'Карельская весна · 21 день, сжатый в 4 часа' }
  ];
  const programsEn = [
    { title: 'Quiet hours: Lake Onega',         meta: 'Recorded by V. Sokolov · Karelia, RU · 04:00 UTC, May 2025 · 4 hours' },
    { title: 'Long-form listening: glaciers',   meta: 'Uninterrupted captures from Vatnajökull and Patagonia' },
    { title: 'Dawn chorus, multi-station',      meta: 'Simulcast · Vodlozersky, Białowieża, Killarney' },
    { title: 'Whistler season',                 meta: 'VLF recordings from the Patagonian array · programmed by D. Ortiz' },
    { title: 'The bazaar tapes',                meta: 'Three Central Asian markets · curated by A. Razzakov' },
    { title: 'A river breaking up',             meta: 'Karelian spring · 21 days compressed to 4 hours' }
  ];
  const programs = lang === 'ru' ? programsRu : programsEn;

  let pi = 0;
  setInterval(() => {
    if (!npTitle || !npMeta) return;
    pi = (pi + 1) % programs.length;
    npTitle.style.opacity = 0;
    npMeta.style.opacity = 0;
    setTimeout(() => {
      npTitle.textContent = programs[pi].title;
      npMeta.textContent  = programs[pi].meta;
      npTitle.style.transition = 'opacity 0.6s';
      npMeta.style.transition  = 'opacity 0.6s';
      npTitle.style.opacity = 1;
      npMeta.style.opacity  = 1;
    }, 600);
  }, 45000);
})();
